import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'summary'
})
export class SummaryPipe implements PipeTransform {
  transform(value: string, ...args: number[]): string {
    var start=args[0]
    var limit=args[1]
    return value.substring(start,limit);
  }
}
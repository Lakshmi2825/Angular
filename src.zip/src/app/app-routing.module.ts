import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { CustomersComponent } from './customers/customers.component';
import { EmployeeComponent } from './employee/employee.component';
import { ServicesComponent } from './services/services.component';

const routes: Routes = [
    {path:"",component:EmployeeComponent},
    {path:"services",component:ServicesComponent},
    {path:"customers",component:CustomersComponent},
    {path:"about-us",component:AboutUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


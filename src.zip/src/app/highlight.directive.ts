import { Directive, ElementRef, HostListener, Input } from '@angular/core';
 
@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {
  // <td [highlight]='green'>
  // <td [highlight]> default:yellow
 
  @Input('highlight')
  color:string
 
  constructor(private currentElem:ElementRef) {
      this.color='yellow' //default value
   }
 
   private changeBackColor(color:string){
      this.currentElem.nativeElement.style.backgroundColor=color     
   }
 
   @HostListener("mouseenter")
   applyBackColorOnMouseOver(){
     this.changeBackColor(this.color)
   }
 
   @HostListener("mouseleave")
   removeBackColoronMouseExit(){
     this.changeBackColor("")
   }
 
}
